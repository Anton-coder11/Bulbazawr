package HW1;

public class work_dilema {

    public static void  printJob() {
        System.out.println("Работа була виконана");

    }


    public static void main(String[] argv){
        printJob();



    }
}
