package HW1;

public class work_dilema {

    public static void  make_a_code() {
        System.out.println("1) Увімкнути ПК");
        System.out.println("2)Зайти до аккаунту");
        System.out.println("3)Відкрити Intellij");
        System.out.println("4)Зробити новий класс джави");
        System.out.println("5)Написати код");
        System.out.println("6)Перевірити чи працюе код");
        System.out.println("7)Віддати роботу до роботодавця");
        System.out.println("8)Отримати оплату у розмірі 5 копіїок і печива");
    }


    public static void main(String[] argv){
        make_a_code();



    }
}
